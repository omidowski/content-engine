from datetime import datetime, timezone
from enum import StrEnum

from sqlalchemy import JSON, DateTime, Enum, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.database import Base


class ContentStatus(StrEnum):
    REVIEW = "REVIEW"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    AUDIO_READY = "AUDIO_READY"
    VIDEO_READY = "VIDEO_READY"


class ContentItem(Base):
    __tablename__ = "content_items"

    id: Mapped[int] = mapped_column(primary_key=True)
    topic: Mapped[str] = mapped_column(String(300))
    language: Mapped[str] = mapped_column(String(10), default="de")
    hook: Mapped[str] = mapped_column(Text)
    script: Mapped[str] = mapped_column(Text)
    title: Mapped[str] = mapped_column(String(300))
    caption: Mapped[str] = mapped_column(Text)
    cta: Mapped[str] = mapped_column(String(300))
    sources: Mapped[list[dict]] = mapped_column(JSON, default=list)
    status: Mapped[ContentStatus] = mapped_column(Enum(ContentStatus), default=ContentStatus.REVIEW)
    audio_path: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    video_path: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )


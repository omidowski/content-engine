"""External and rendering services."""

